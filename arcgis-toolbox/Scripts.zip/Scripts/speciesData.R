tool_exec <- function(in_params, out_params)
{
  #### Load library ####
  message("Loading Library...")
  if (!requireNamespace("dismo", quietly = TRUE))
    install.packages("dismo")
  if (!requireNamespace("jsonlite", quietly = TRUE))
    install.packages("jsonlite")
  if (!requireNamespace("sp", quietly = TRUE))
    install.packages("sp")
  
  require(dismo)
  require(jsonlite)
  require(sp)
  
  #### Get input parameters ####
  message("Reading Input Parameters...")
  genus_str <- in_params[[1]]
  species_str <- in_params[[2]]
 
  ext_file <- in_params[[3]]
  
  year_range <- in_params[[4]]
  #end_year <- in_params[[5]]
  month_range <- in_params[[5]]
  #end_month <- in_params[[7]]
  ele_range <- in_params[[6]]
  #end_ele <- in_params[[9]]
  dep_range <- in_params[[7]]
  #end_dep <- in_params[[11]]
  
  
  
  #### Set output parameters ####
  #out_csv <- out_params[[1]]
  #out_map <- out_params[[1]]
  
  #message("Reading System Layer...")
  #background_map <- arc.open(systemLayer)
  
  #message("Creating Output Shapefile...")
  #SPDF = SpatialPolygonsDataFrame(tc_systems_spdf, data=tc_systems_df_join)
  #shape_info <- list(type="Polygon", WKT=arc.shapeinfo(arc.shape(tc_systems_df))$WKT)
  
  ### Assign arguments ###
  if (is.null(year_range)== FALSE){
    info <- gbif(genus=genus_str,species=species_str,ext=ext_file,args=paste('"year="',year_range,'"'),geo=TRUE,sp=TRUE,removeZeros=FALSE,download=TRUE,ntries=5,nrecs=300,start=1,end=Inf)
  }
  if (is.null(month_range)== FALSE){
    info <- gbif(genus=genus_str,species=species_str,ext=ext_file,args=paste('"month="',month_range,'"'),geo=TRUE,sp=TRUE,removeZeros=FALSE,download=TRUE,ntries=5,nrecs=300,start=1,end=Inf)
  }
  if (is.null(ele_range)== FALSE){
    info <- gbif(genus=genus_str,species=species_str,ext=ext_file,args=paste('"elevation="',ele_range,'"'),geo=TRUE,sp=TRUE,removeZeros=FALSE,download=TRUE,ntries=5,nrecs=300,start=1,end=Inf)
  }
  if (is.null(dep_range)== FALSE){
    info <- gbif(genus=genus_str,species=species_str,ext=ext_file,args=paste('"depth="',dep_range,'"'),geo=TRUE,sp=TRUE,removeZeros=FALSE,download=TRUE,ntries=5,nrecs=300,start=1,end=Inf)
  }
  #info <- gbif(genus=genus_str,species=species_str,ext=ext_file,args="year=1800,1899",geo=TRUE,sp=TRUE,removeZeros=FALSE,download=TRUE,ntries=5,nrecs=300,start=1,end=Inf)
  
  message("Creating Output Files...")
  print("Species Report:", quote = FALSE)
  print(info)
  
  result = tryCatch({
    #pdf(out_pdf)
    
    suppressWarnings(plot(info))
    
    
  }, finally = {
    dev.off()
  }
  )
  #write.csv(info,file = out_csv)
  return(out_params)
}

#List of genus and species can be found @
#https://www.gbif.org/occurrence/taxonomy?advanced=1