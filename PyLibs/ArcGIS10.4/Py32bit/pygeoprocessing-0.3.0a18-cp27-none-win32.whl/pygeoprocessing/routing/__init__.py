"""__init__ module for routing that cleans up the namespace of the functions
	inside the routing source"""

from pygeoprocessing.routing.routing import *
