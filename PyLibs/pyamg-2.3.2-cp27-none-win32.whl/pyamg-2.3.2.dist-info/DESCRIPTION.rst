PyAMG is a library of Algebraic Multigrid (AMG) solvers
with a convenient Python interface.


