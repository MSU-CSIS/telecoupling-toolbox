
# this file is generated from pyamg in setup.py
short_version = '2.3.2'
version = '2.3.2'
full_version = '2.3.2'
git_revision = '2.3.2-1-gbc65767'
release = True

if not release:
    version = full_version
