"""amg_core - a C++ implementation of AMG-related routines
"""
from amg_core import *
