Copy ca_ozone_pts.shp from \\bugs\share\R-for-Pro\examples\data

